# calculate the adjusted fitness, decide the proportion of removed
# genomes in each species and allocate each new_born genomes
# species(could be a new one)

import crossover_and_mutation