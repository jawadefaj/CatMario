## NOTES ##

This example currently does not work as intended. 

## Fixed-length Sequence Memory Evolution ##

`evolve.py` Generates networks to reproduce a fixed-length sequence of binary inputs.

