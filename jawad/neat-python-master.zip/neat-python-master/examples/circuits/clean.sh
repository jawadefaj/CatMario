#!/usr/bin/env bash
rm *.csv *.svg *.gv